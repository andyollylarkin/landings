(function(){const a=document.createElement("link").relList;if(a&&a.supports&&a.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))i(s);new MutationObserver(s=>{for(const n of s)if(n.type==="childList")for(const u of n.addedNodes)u.tagName==="LINK"&&u.rel==="modulepreload"&&i(u)}).observe(document,{childList:!0,subtree:!0});function t(s){const n={};return s.integrity&&(n.integrity=s.integrity),s.referrerPolicy&&(n.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?n.credentials="include":s.crossOrigin==="anonymous"?n.credentials="omit":n.credentials="same-origin",n}function i(s){if(s.ep)return;s.ep=!0;const n=t(s);fetch(s.href,n)}})();const x=document.querySelector("#app");x.innerHTML=`
  <div class="page-shell">
    <header class="site-header" role="banner">
      <div class="header-inner container">
        <a class="brand" href="#main-content" aria-label="DataForge home">
          <span class="brand-mark" aria-hidden="true"></span>
          <span class="brand-title">DataForge</span>
        </a>
        <button class="nav-toggle" type="button" aria-expanded="false" aria-controls="primary-navigation">
          <span class="nav-toggle-bar" aria-hidden="true"></span>
          <span class="nav-toggle-bar" aria-hidden="true"></span>
          <span class="nav-toggle-bar" aria-hidden="true"></span>
          <span class="nav-toggle-label">Menu</span>
        </button>
        <nav class="site-nav" id="primary-navigation" aria-label="Main navigation">
          <ul class="nav-list">
            <li><a href="#services">Services</a></li>
            <li><a href="#case-studies">Case Studies</a></li>
            <li><a href="#pricing">Pricing</a></li>
            <li><a href="#faq">FAQ</a></li>
            <li><a href="#about">About</a></li>
          </ul>
          <button class="button button-primary nav-cta js-modal-trigger" type="button" data-modal-target="contact">
            Get Free Sample
          </button>
        </nav>
      </div>
    </header>

    <main id="main-content" class="page-main" tabindex="-1">
      <section class="hero" aria-labelledby="hero-title">
        <div class="hero-gradient" aria-hidden="true"></div>
        <div class="container hero-inner">
          <div class="hero-copy" data-animate="fade-up">
            <span class="eyebrow">Job market intelligence, delivered</span>
            <h1 id="hero-title">
              Custom Job Market Data Extraction—
              <span class="highlight">Delivered in 48 Hours</span>, formatted for your systems
            </h1>
            <p class="hero-subhead">
              LinkedIn, Indeed, Glassdoor, and every major job board. No anti-bot blocks. No internal development roadmap. Just structured job market data ready for analysis.
            </p>
            <div class="hero-actions" data-animate="fade-up" data-animate-delay="100">
              <button class="button button-primary button-large js-modal-trigger" type="button" data-modal-target="contact">
                Get a Free Custom Data Sample
              </button>
              <a class="button button-secondary" href="#process">
                See how it works
              </a>
            </div>
            <p class="button-subtext">
              See your exact use case in 48 hours—no credit card required
            </p>
            <ul class="trust-list" aria-label="DataForge trust signals" data-animate="fade-up" data-animate-delay="180">
              <li>
                <svg class="icon" viewBox="0 0 20 20" aria-hidden="true">
                  <path d="M8.3 14.2 4.5 10.5l1.4-1.4 2.4 2.4 5.8-5.8 1.4 1.4-7.2 7.1z" />
                </svg>
                500+ custom projects delivered
              </li>
              <li>
                <svg class="icon" viewBox="0 0 20 20" aria-hidden="true">
                  <path d="M8.3 14.2 4.5 10.5l1.4-1.4 2.4 2.4 5.8-5.8 1.4 1.4-7.2 7.1z" />
                </svg>
                GDPR-aligned extraction workflows
              </li>
              <li>
                <svg class="icon" viewBox="0 0 20 20" aria-hidden="true">
                  <path d="M8.3 14.2 4.5 10.5l1.4-1.4 2.4 2.4 5.8-5.8 1.4 1.4-7.2 7.1z" />
                </svg>
                99.5% structured data accuracy guarantee
              </li>
            </ul>
          </div>
          <div class="hero-visual" aria-hidden="true" data-animate="scale-in" data-animate-delay="120">
            <div class="visual-card visual-raw">
              <div class="visual-label">Raw job post view</div>
              <div class="raw-header">
                <div class="raw-avatar"></div>
                <div class="raw-meta">
                  <div class="raw-title shimmer"></div>
                  <div class="raw-sub shimmer"></div>
                </div>
              </div>
              <div class="raw-badges">
                <span class="raw-badge"></span>
                <span class="raw-badge"></span>
                <span class="raw-badge"></span>
              </div>
              <div class="raw-body shimmer"></div>
              <div class="raw-body shimmer short"></div>
              <div class="raw-body shimmer short"></div>
            </div>
            <div class="visual-bridge">
              <span class="bridge-badge">48 hours</span>
              <svg class="bridge-arrow" viewBox="0 0 40 16">
                <path d="M0 8h32" />
                <path d="M24 1.5 32 8l-8 6.5" />
              </svg>
              <div class="bridge-matrix">
                <span></span><span></span><span></span><span></span>
              </div>
            </div>
            <div class="visual-card visual-structured">
              <div class="visual-label">Structured dataset</div>
              <div class="structured-header">
                <div class="pill">Updated 2 hours ago</div>
              </div>
              <div class="structured-grid" role="presentation">
                <div class="grid-rowset grid-rowset-header" aria-hidden="true">
                  <span class="grid-cell">Company</span>
                  <span class="grid-cell">Role</span>
                  <span class="grid-cell">Compensation</span>
                  <span class="grid-cell">Location</span>
                </div>
                <div class="grid-rowset">
                  <span class="grid-cell" data-label="Company">Meta</span>
                  <span class="grid-cell" data-label="Role">Staff Data Engineer</span>
                  <span class="grid-cell" data-label="Compensation">$150K – $180K</span>
                  <span class="grid-cell" data-label="Location">Remote</span>
                </div>
                <div class="grid-rowset">
                  <span class="grid-cell" data-label="Company">Google</span>
                  <span class="grid-cell" data-label="Role">Machine Learning Lead</span>
                  <span class="grid-cell" data-label="Compensation">$160K – $200K</span>
                  <span class="grid-cell" data-label="Location">Mountain View</span>
                </div>
                <div class="grid-rowset">
                  <span class="grid-cell" data-label="Company">Amazon</span>
                  <span class="grid-cell" data-label="Role">Analytics Strategist</span>
                  <span class="grid-cell" data-label="Compensation">$110K – $140K</span>
                  <span class="grid-cell" data-label="Location">Seattle</span>
                </div>
              </div>
              <div class="structured-footer">
                <span class="structured-token">CSV</span>
                <span class="structured-token">JSON</span>
                <span class="structured-token">API</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="social-proof" aria-label="Social proof">
        <div class="container social-proof-inner">
          <p class="social-proof-title">Trusted by growth teams across recruiting, analytics, and HR tech</p>
          <div class="logo-grid" data-animate="fade-up">
            <span>TalentEdge</span>
            <span>BlueSky Research</span>
            <span>RecruitIQ</span>
            <span>InsightLoop</span>
            <span>HireSignal</span>
            <span>Vector People</span>
          </div>
        </div>
      </section>

      <section class="case-studies" id="case-studies" aria-labelledby="case-studies-title">
        <div class="container case-studies-inner">
          <p class="section-badge">Proven outcomes</p>
          <h2 id="case-studies-title">How DataForge powers job market intelligence</h2>
          <p class="section-intro">
            Real examples from recruiting, workforce planning, and analytics teams using our extraction infrastructure to stay ahead of hiring trends.
          </p>
          <div class="case-grid">
            <article class="case-card" data-animate="fade-up">
              <div class="case-meta">
                <span class="case-tag">HR Tech Platform</span>
                <span class="case-metric">4x more coverage</span>
              </div>
              <h3>Aggregated 12 job boards into one live talent feed</h3>
              <p>
                A recruiting SaaS firm replaced manual sourcing with our automated feed, capturing daily updates across North America and Europe while delivering structured alerts to their clients.
              </p>
              <ul>
                <li><span class="point-dot"></span>12 job sources normalized</li>
                <li><span class="point-dot"></span>Daily refresh with webhook delivery</li>
                <li><span class="point-dot"></span>Lead response time cut from 48h to 6h</li>
              </ul>
            </article>
            <article class="case-card" data-animate="fade-up" data-animate-delay="120">
              <div class="case-meta">
                <span class="case-tag">Enterprise Retail</span>
                <span class="case-metric">$3.2M saved</span>
              </div>
              <h3>Mapped competitor hiring to optimize regional staffing budgets</h3>
              <p>
                DataForge monitored 30 competitors and surfaced salary shifts, allowing the finance team to reallocate headcount and avoid overpaying in saturated markets.
              </p>
              <ul>
                <li><span class="point-dot"></span>30 competitor brands tracked weekly</li>
                <li><span class="point-dot"></span>Compensation insights integrated with BI</li>
                <li><span class="point-dot"></span>Staffing efficiency gains across 220 stores</li>
              </ul>
            </article>
            <article class="case-card" data-animate="fade-up" data-animate-delay="200">
              <div class="case-meta">
                <span class="case-tag">Market Research</span>
                <span class="case-metric">Launch in 21 days</span>
              </div>
              <h3>Built a subscription-ready salary benchmark dataset</h3>
              <p>
                A research consultancy used our structured exports to launch a new subscription product covering emerging tech roles, complete with historic trend analysis.
              </p>
              <ul>
                <li><span class="point-dot"></span>Historical dataset rebuilt from 18 months</li>
                <li><span class="point-dot"></span>Automated uploads to Snowflake</li>
                <li><span class="point-dot"></span>New revenue stream within one quarter</li>
              </ul>
            </article>
          </div>
        </div>
      </section>

      <section class="problems" id="services" aria-labelledby="problem-title">
        <div class="container problems-inner">
          <h2 id="problem-title">Why teams burn months building the data infrastructure we ship in days</h2>
          <p class="section-intro">
            You already know fresh job market intelligence is critical. But every path you try is expensive, slow, or incomplete.
          </p>
          <div class="problem-grid">
            <article class="problem-card" data-animate="fade-up">
              <div class="card-icon" aria-hidden="true">
                <span class="icon-dot"></span>
                <span class="icon-dot"></span>
              </div>
              <h3>Job board APIs deliver partial insights</h3>
              <p>
                Official APIs lock critical data points behind premium tiers and strict rate limits. Salary ranges, posting velocity, and skill requirements never make it into your dashboards.
              </p>
              <ul class="card-points">
                <li><span class="point-dot"></span>High annual fees with narrow coverage</li>
                <li><span class="point-dot"></span>Volume caps that stall enterprise research</li>
                <li><span class="point-dot"></span>No visibility into unlisted compensation data</li>
              </ul>
            </article>
            <article class="problem-card" data-animate="fade-up" data-animate-delay="120">
              <div class="card-icon" aria-hidden="true">
                <span class="icon-dot"></span>
                <span class="icon-dot"></span>
              </div>
              <h3>Manual collection drains analyst hours</h3>
              <p>
                Copying listings into spreadsheets for twenty hours a week is not a strategy. Human error compounds, formats drift, and insights arrive too late to matter.
              </p>
              <ul class="card-points">
                <li><span class="point-dot"></span>Analysts stuck on repetitive workflows</li>
                <li><span class="point-dot"></span>Inconsistent formatting across sources</li>
                <li><span class="point-dot"></span>Insights delivered after the market shifts</li>
              </ul>
            </article>
            <article class="problem-card" data-animate="fade-up" data-animate-delay="200">
              <div class="card-icon" aria-hidden="true">
                <span class="icon-dot"></span>
                <span class="icon-dot"></span>
              </div>
              <h3>In-house scrapers break every release cycle</h3>
              <p>
                Anti-bot controls evolve weekly. Captchas, IP fingerprints, and dynamic rendering snap brittle scripts, forcing constant maintenance sprints.
              </p>
              <ul class="card-points">
                <li><span class="point-dot"></span>Hidden infrastructure costs stack up</li>
                <li><span class="point-dot"></span>Downtime every time HTML shifts</li>
                <li><span class="point-dot"></span>Security reviews slow every update</li>
              </ul>
            </article>
          </div>
        </div>
        <div class="problem-agitation">
          <div class="container agitation-inner" data-animate="fade-up">
            <p>
              You are not in the scraping business. You are in the hiring intelligence business. Every hour spent on infrastructure is opportunity lost on insight, positioning, and action.
            </p>
            <svg class="agitation-arrow" viewBox="0 0 24 24" aria-hidden="true">
              <path d="M12 4v16M5 13l7 7 7-7" />
            </svg>
          </div>
        </div>
      </section>

      <section class="solution" id="process" aria-labelledby="solution-title">
        <div class="container solution-inner">
          <p class="section-badge">The DataForge approach</p>
          <h2 id="solution-title">We handle the complexity, you keep the advantage</h2>
          <p class="section-intro">
            Our engineering team scopes, extracts, and maintains your job market data pipeline. You get flexible delivery, ongoing monitoring, and insights that stay current.
          </p>
          <div class="solution-layout">
            <div class="solution-visual" aria-hidden="true" data-animate="fade-up">
              <div class="timeline">
                <div class="timeline-item">
                  <span class="timeline-bullet"></span>
                  <div>
                    <h3>Discovery blueprint</h3>
                    <p>30-minute call to capture sourcing targets, refresh cadence, and delivery format.</p>
                  </div>
                </div>
                <div class="timeline-item">
                  <span class="timeline-bullet"></span>
                  <div>
                    <h3>Extraction engine</h3>
                    <p>Custom renderers defeat anti-bot barriers with rotating infrastructure tuned per site.</p>
                  </div>
                </div>
                <div class="timeline-item">
                  <span class="timeline-bullet"></span>
                  <div>
                    <h3>Structured delivery</h3>
                    <p>Normalized datasets dropped into CSV, JSON, warehouse tables, or webhook payloads.</p>
                  </div>
                </div>
                <div class="timeline-item">
                  <span class="timeline-bullet"></span>
                  <div>
                    <h3>Continuous monitoring</h3>
                    <p>Automated change detection keeps schemas aligned as job boards evolve.</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="solution-copy">
              <article data-animate="fade-up">
                <h3>Full-service extraction</h3>
                <p>From scoping targets to handling quality checks, our senior engineers operate the entire pipeline so your team stays focused on strategy.</p>
              </article>
              <article data-animate="fade-up" data-animate-delay="120">
                <h3>Barrier-proof infrastructure</h3>
                <p>Enterprise-grade rendering, fingerprint rotation, and headless orchestration keep data flowing even as defenses adapt.</p>
              </article>
              <article data-animate="fade-up" data-animate-delay="200">
                <h3>Delivery on your terms</h3>
                <p>Schedule updates daily, weekly, or in real time. Consume in spreadsheets, analytics stacks, or direct integrations.</p>
              </article>
              <article data-animate="fade-up" data-animate-delay="280">
                <h3>Ongoing resilience</h3>
                <p>We maintain your extraction logic, test new selectors, and monitor drift so you never lose visibility into the market.</p>
              </article>
            </div>
          </div>
        </div>
      </section>

      <section class="pricing" id="pricing" aria-labelledby="pricing-title">
        <div class="container pricing-inner">
          <p class="section-badge">Flexible engagements</p>
          <h2 id="pricing-title">Project-based pricing aligned to your data scope</h2>
          <p class="section-intro">
            Start with a scoped pilot to validate deliverables, expand into recurring refreshes once the dataset powers your workflows.
          </p>
          <div class="pricing-grid">
            <article class="pricing-card" data-animate="fade-up">
              <div class="pricing-header">
                <span class="pricing-tag">Pilot</span>
                <h3>Single site assessment</h3>
                <p class="pricing-number">From $2,500</p>
              </div>
              <ul class="pricing-points">
                <li><span class="point-dot"></span>One job board or geography</li>
                <li><span class="point-dot"></span>5,000 structured listings delivered</li>
                <li><span class="point-dot"></span>One-time delivery within 7 days</li>
                <li><span class="point-dot"></span>Implementation roadmap included</li>
              </ul>
              <button class="button button-secondary js-modal-trigger" type="button" data-modal-target="contact">
                Discuss pilot
              </button>
            </article>
            <article class="pricing-card pricing-card-featured" data-animate="fade-up" data-animate-delay="120">
              <div class="pricing-header">
                <span class="pricing-tag">Most popular</span>
                <h3>Growth monitoring</h3>
                <p class="pricing-number">From $4,800 / month</p>
              </div>
              <ul class="pricing-points">
                <li><span class="point-dot"></span>Up to five job sources or regions</li>
                <li><span class="point-dot"></span>Rolling refresh cadence (daily or weekly)</li>
                <li><span class="point-dot"></span>Change detection and schema maintenance</li>
                <li><span class="point-dot"></span>Warehouse, CSV, and webhook delivery</li>
              </ul>
              <button class="button button-primary js-modal-trigger" type="button" data-modal-target="contact">
                Plan my rollout
              </button>
            </article>
            <article class="pricing-card" data-animate="fade-up" data-animate-delay="200">
              <div class="pricing-header">
                <span class="pricing-tag">Enterprise</span>
                <h3>Global talent intelligence</h3>
                <p class="pricing-number">Custom</p>
              </div>
              <ul class="pricing-points">
                <li><span class="point-dot"></span>Unlimited sources with compliance review</li>
                <li><span class="point-dot"></span>SLA-backed delivery windows</li>
                <li><span class="point-dot"></span>Dedicated engineering pod</li>
                <li><span class="point-dot"></span>Integration with analytics and CRM systems</li>
              </ul>
              <button class="button button-secondary js-modal-trigger" type="button" data-modal-target="contact">
                Talk to us
              </button>
            </article>
          </div>
        </div>
      </section>

      <section class="faq" id="faq" aria-labelledby="faq-title">
        <div class="container faq-inner">
          <p class="section-badge">Questions, answered</p>
          <h2 id="faq-title">FAQ about DataForge job data extraction</h2>
          <div class="faq-grid">
            <div class="faq-copy" data-animate="fade-up">
              <p>
                Still wondering about how we source, secure, or deliver job market data? Browse the answers below or open the contact form to reach our team directly.
              </p>
              <button class="button button-secondary js-modal-trigger" type="button" data-modal-target="contact">
                Connect with a manager
              </button>
            </div>
            <div class="faq-accordion" role="list">
              <article class="faq-item" role="listitem" data-animate="fade-up" data-animate-delay="80">
                <button class="faq-question" type="button" aria-expanded="false">
                  <span>How do you avoid being blocked by job boards?</span>
                  <span class="faq-icon" aria-hidden="true"></span>
                </button>
                <div class="faq-answer">
                  <p>
                    We render pages in headless environments with rotating infrastructure, adaptive fingerprinting, and captcha handling. Every extraction route is monitored so we can respond instantly when a site ships an update.
                  </p>
                </div>
              </article>
              <article class="faq-item" role="listitem" data-animate="fade-up" data-animate-delay="140">
                <button class="faq-question" type="button" aria-expanded="false">
                  <span>Which formats can you deliver?</span>
                  <span class="faq-icon" aria-hidden="true"></span>
                </button>
                <div class="faq-answer">
                  <p>
                    We support CSV, JSON, Snowflake, BigQuery, Redshift, S3, and webhook payloads. During onboarding we map the fields to match your schema so the data slots straight into your analytics stack.
                  </p>
                </div>
              </article>
              <article class="faq-item" role="listitem" data-animate="fade-up" data-animate-delay="200">
                <button class="faq-question" type="button" aria-expanded="false">
                  <span>Can you keep the data refreshed automatically?</span>
                  <span class="faq-icon" aria-hidden="true"></span>
                </button>
                <div class="faq-answer">
                  <p>
                    Yes. We schedule extraction cadences to your needs—daily, weekly, or event-driven. When a site’s markup changes, our engineers adjust the logic without interrupting your feed.
                  </p>
                </div>
              </article>
              <article class="faq-item" role="listitem" data-animate="fade-up" data-animate-delay="260">
                <button class="faq-question" type="button" aria-expanded="false">
                  <span>What about compliance and local regulations?</span>
                  <span class="faq-icon" aria-hidden="true"></span>
                </button>
                <div class="faq-answer">
                  <p>
                    We run every engagement through legal review, respect robots directives where binding, and anonymize personal data fields. You receive a compliance summary with each project kickoff.
                  </p>
                </div>
              </article>
            </div>
          </div>
        </div>
      </section>

      <section class="cta-closing" id="cta" aria-labelledby="cta-title">
  <div class="container cta-inner" data-animate="fade-up">
          <h2 id="cta-title">See your custom dataset in 48 hours</h2>
          <p>Share your job boards, fields, and delivery preferences. We will ship a tailored sample and roadmap after a single discovery session.</p>
          <div class="cta-actions">
            <button class="button button-primary button-large js-modal-trigger" type="button" data-modal-target="contact">
              Schedule a discovery call
            </button>
            <a class="button button-secondary" href="#case-studies">
              Explore use cases
            </a>
          </div>
        </div>
      </section>
    </main>

    <footer class="site-footer" id="about">
      <div class="container footer-inner">
        <div>
          <div class="brand footer-brand">
            <span class="brand-mark" aria-hidden="true"></span>
            <span class="brand-title">DataForge</span>
          </div>
          <p>High-fidelity job market intelligence for recruiting, analytics, and workforce planning teams.</p>
        </div>
        <div class="footer-columns">
          <div>
            <h3>Company</h3>
            <ul>
              <li><a href="#services">Services</a></li>
              <li><a href="#process">Process</a></li>
              <li><a href="#cta">Contact</a></li>
            </ul>
          </div>
          <div>
            <h3>Resources</h3>
            <ul>
              <li><a href="#case-studies">Case Studies</a></li>
              <li><a href="#pricing">Pricing</a></li>
              <li><a href="#about">About</a></li>
            </ul>
          </div>
        </div>
      </div>
      <div class="footer-bottom">
        <div class="container footer-bottom-inner">
          <span>© ${new Date().getFullYear()} DataForge. All rights reserved.</span>
          <a href="#">Privacy</a>
        </div>
      </div>
    </footer>

    <div class="mobile-cta" role="dialog" aria-live="polite">
      <button class="mobile-cta-close" type="button" aria-label="Close quick action">
        <span aria-hidden="true">X</span>
      </button>
      <button class="button button-primary js-modal-trigger" type="button" data-modal-target="contact">
        Get Free Sample
      </button>
    </div>
    <div class="modal-backdrop" data-modal-id="contact" aria-hidden="true">
      <div class="modal-layer" data-modal-close="true"></div>
      <div class="modal-window" role="dialog" aria-modal="true" aria-labelledby="contact-modal-title">
        <button class="modal-close" type="button" aria-label="Close contact form" data-modal-close="true">
          <span aria-hidden="true">X</span>
        </button>
        <div class="modal-header">
          <span class="modal-kicker">Contact our manager</span>
          <h2 id="contact-modal-title">Book a discovery call with DataForge</h2>
          <p>Share a few details about your hiring intelligence needs and our manager will connect within one business day.</p>
        </div>
        <form class="contact-form" id="contact-form">
          <div class="form-grid">
            <label class="form-field">
              <span>Full name</span>
              <input type="text" name="fullName" autocomplete="name" required />
            </label>
            <label class="form-field">
              <span>Work email</span>
              <input type="email" name="email" autocomplete="email" inputmode="email" required />
            </label>
            <label class="form-field form-field-full">
              <span>Project details</span>
              <textarea name="projectDetails" rows="4" placeholder="Tell us about the job boards, geographies, and cadence you need." required></textarea>
            </label>
          </div>
          <label class="form-checkbox">
            <input type="checkbox" name="consent" required />
            <span>I agree to be contacted by a DataForge specialist regarding this request.</span>
          </label>
          <button class="button button-primary button-large" type="submit">
            Submit request
          </button>
          <p class="form-assist">We will reach out within one business day. Prefer email? <a href="mailto:hello@dataforge.com">hello@dataforge.com</a></p>
          <p class="form-status" role="status" aria-live="polite"></p>
        </form>
      </div>
    </div>
  </div>
`;const m=document.querySelector(".site-header"),c=document.querySelector(".nav-toggle"),d=document.querySelector(".site-nav"),h=document.body;if(m){const e=()=>{window.scrollY>8?m.classList.add("is-scrolled"):m.classList.remove("is-scrolled")};window.addEventListener("scroll",e),e()}if(d&&c){const e=()=>{const a=c.getAttribute("aria-expanded")==="true";c.setAttribute("aria-expanded",String(!a)),d.classList.toggle("is-open",!a),h.classList.toggle("no-scroll",!a)};c.addEventListener("click",e),d.querySelectorAll("a").forEach(a=>{a.addEventListener("click",()=>{d.classList.contains("is-open")&&e()})})}const o=document.querySelector(".mobile-cta"),b=document.querySelector(".hero"),f=document.querySelector(".cta-closing"),y=document.querySelector(".mobile-cta-close");let w=!1;if(o&&y){const e=new IntersectionObserver(a=>{a.forEach(t=>{w||(t.isIntersecting?o.classList.remove("is-visible"):o.classList.add("is-visible"))})},{rootMargin:"-120px 0px 0px 0px"});b&&e.observe(b),f&&new IntersectionObserver(t=>{t.forEach(i=>{i.isIntersecting&&o.classList.remove("is-visible")})},{threshold:.2}).observe(f),y.addEventListener("click",()=>{w=!0,o.classList.remove("is-visible")})}const L='a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';let r=null,p=null;const k=e=>Array.from(e.querySelectorAll(L)).filter(a=>!(a.offsetParent===null&&getComputedStyle(a).position!=="fixed")),S=e=>{if(!r)return;if(e.key==="Escape"){e.preventDefault(),q();return}if(e.key!=="Tab")return;const a=k(r);if(!a.length)return;const t=a[0],i=a[a.length-1];if(e.shiftKey){document.activeElement===t&&(e.preventDefault(),i.focus());return}document.activeElement===i&&(e.preventDefault(),t.focus())},E=e=>{const a=document.querySelector(`[data-modal-id="${e}"]`);if(!a)return;p=document.activeElement,r=a,a.classList.add("is-open"),a.setAttribute("aria-hidden","false"),h.classList.add("modal-open");const t=a.querySelector(".form-status");t&&(t.textContent="",t.classList.remove("is-visible"));const i=a.querySelector("form");i&&i.classList.remove("is-success");const s=k(a);s.length&&s[0].focus(),document.addEventListener("keydown",S)},q=()=>{r&&(r.classList.remove("is-open"),r.setAttribute("aria-hidden","true"),h.classList.remove("modal-open"),document.removeEventListener("keydown",S),p&&p.focus(),r=null,p=null)};document.querySelectorAll(".js-modal-trigger").forEach(e=>{e.addEventListener("click",()=>{const a=e.getAttribute("data-modal-target");a&&E(a)})});document.querySelectorAll('[data-modal-close="true"]').forEach(e=>{e.addEventListener("click",a=>{a.preventDefault(),q()})});document.querySelectorAll(".modal-window").forEach(e=>{e.addEventListener("click",a=>{a.stopPropagation()})});const l=document.querySelector("#contact-form"),g=l?.querySelector(".form-status");l&&g&&l.addEventListener("submit",e=>{e.preventDefault(),g.textContent="Thanks! Our manager will reach out within one business day.",g.classList.add("is-visible"),l.classList.add("is-success"),l.reset()});document.querySelectorAll(".faq-item").forEach(e=>{const a=e.querySelector(".faq-question"),t=e.querySelector(".faq-answer");if(!a||!t)return;t.style.maxHeight="0px";const i=s=>{a.setAttribute("aria-expanded",String(s)),e.classList.toggle("is-open",s),s?t.style.maxHeight=`${t.scrollHeight}px`:(t.style.maxHeight=`${t.scrollHeight}px`,requestAnimationFrame(()=>{t.style.maxHeight="0px"}))};a.addEventListener("click",()=>{const s=e.classList.contains("is-open");i(!s)}),t.addEventListener("transitionend",s=>{if(s.propertyName==="max-height"){if(e.classList.contains("is-open")){t.style.maxHeight="none";return}t.style.maxHeight="0px"}})});const v=document.querySelectorAll("[data-animate]");if(v.length)if(window.matchMedia("(prefers-reduced-motion: reduce)").matches)v.forEach(a=>a.classList.add("is-animated"));else{const a=new IntersectionObserver(t=>{t.forEach(i=>{i.isIntersecting&&(i.target.classList.add("is-animated"),a.unobserve(i.target))})},{threshold:.15,rootMargin:"0px 0px -40px 0px"});v.forEach(t=>a.observe(t))}
